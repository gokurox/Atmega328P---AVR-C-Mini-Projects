#ifndef HELLO_h
#define HELLO_h

void printHello ();

#endif
