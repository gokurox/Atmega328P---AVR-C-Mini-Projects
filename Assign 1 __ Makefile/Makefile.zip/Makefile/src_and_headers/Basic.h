#ifndef BASIC
#define BASIC

#include <stdio.h>
#include <stdlib.h>

#endif
