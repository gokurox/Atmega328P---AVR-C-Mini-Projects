#include "Hello.h"
#include "World.h"

#define begin main

int begin (void)
{
	printHello ();
	printWorld ();
	return 0;
}
