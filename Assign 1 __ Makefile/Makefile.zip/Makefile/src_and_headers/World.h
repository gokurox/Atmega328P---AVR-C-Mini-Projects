#ifndef WORLD_h
#define WORLD_h

void printWorld ();

#endif
