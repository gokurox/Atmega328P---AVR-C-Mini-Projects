/*
 *			This file defines how to Print "WORLD"
 */
 
 #include "Basic.h"
 
 void printWorld ()
 {
 	printf ("WORLD\n");
 }
