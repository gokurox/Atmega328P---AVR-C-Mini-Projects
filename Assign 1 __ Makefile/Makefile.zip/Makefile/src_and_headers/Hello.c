/*
 *			This file defines how to Print "HELLO"
 */

#include "Basic.h"

void printHello ()
{
	printf ("HELLO ");
}
